import "@mantine/core/styles.css";
import "@mantine/charts/styles.css";
import "@/styles/global.scss";

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
