export const APP_NAME = 'ZARO';
export const APP_TAGLINE = 'Admin panel';

export const common = {
  cancel: 'Bekor qilish',
  create: 'Yaratish',
  save: 'Saqlash',
  delete: "O'chirish",
  edit: 'Tahrirlash',
  actions: 'Amallar',
  active: 'Faol',
  inactive: 'Nofaol',
  somethingWentWrong: 'Xatolik yuz berdi',
  signIn: 'Kirish',
  username: 'Username',
  password: 'Parol',
  usernamePlaceholder: 'Foydalanuvchi nomingiz',
  passwordPlaceholder: 'Parolingiz',
  logout: 'Chiqish',
  expandSidebar: 'Yon panelni kengaytirish',
  collapseSidebar: "Yon panelni yig'ish",
  switchToLight: "Yorug' rejimga o'tish",
  switchToDark: "Qorong'u rejimga o'tish",
  updateStatus: 'Holatni yangilash',
  filter: 'Filtrlash',
  clear: 'Tozalash',
  uncategorized: "Bo'limlarsiz",
  dash: '—',
  id: 'ID'
} as const;

export const tables = {
  allProducts: 'Barcha mahsulotlar',
  allCategories: "Barcha bo'limlar",
  allOrders: 'Barcha buyurtmalar',
  allAttributes: 'Barcha atributlar',
  orderItems: 'Buyurtma tarkibi'
} as const;

export const nav = {
  groups: {
    overview: 'Umumiy',
    catalog: 'Katalog',
    sales: 'Savdo'
  },
  dashboard: 'Asosiy',
  products: 'Mahsulotlar',
  categories: "Bo'limlar",
  orders: 'Buyurtmalar',
  users: 'Mijozlar',
  userTesting: 'Foydalanuvchi testi'
} as const;

export const orderStatus = {
  pending: 'Kutilmoqda',
  paid: "To'langan",
  processing: 'Jarayonda',
  shipped: 'Yuborilgan',
  delivered: 'Yetkazilgan',
  cancelled: 'Bekor qilingan'
} as const;

export const login = {
  title: 'Boshqaruv paneliga kirish',
  success: 'Muvaffaqiyatli kirdingiz',
  invalidCredentials: "Noto'g'ri foydalanuvchi nomi yoki parol. Faqat admin hisoblar kirishi mumkin.",
  missingAdminId: 'VITE_ADMIN_ID .env faylida sozlanmagan. Serverni qayta ishga tushiring.',
  missingApiUrl: 'VITE_API_BASE_URL .env faylida sozlanmagan. Serverni qayta ishga tushiring.',
  apiError: 'API orqali token olish muvaffaqiyatsiz. Internet aloqasini va .env sozlamalarini tekshiring.'
} as const;

export const dashboard = {
  welcome: 'Analitika',
  overview: 'Analitika — buyurtmalar, daromad, katalog holati va bozor faolligini kuzating.',
  customers: 'Mijozlar',
  products: 'Mahsulotlar',
  categories: "Bo'limlar",
  orders: 'Buyurtmalar',
  activeProducts: 'Faol mahsulotlar',
  totalRevenue: 'Umumiy daromad',
  averageOrder: "O'rtacha buyurtma",
  ordersRevenue: 'Buyurtmalar va daromad',
  ordersRevenueDesc: "So'nggi 14 kunlik kunlik buyurtmalar va daromad",
  ordersLegend: 'Buyurtmalar',
  revenueLegend: 'Daromad (UZS)',
  orderStatus: 'Buyurtma holati',
  orderStatusDesc: "Bajarish holati bo'yicha buyurtmalar taqsimoti",
  ordersCount: (count: number) => `${count}\nBuyurtma`,
  noOrders: "Hali buyurtmalar yo'q",
  productsByCategory: "Bo'lim bo'yicha mahsulotlar",
  productsByCategoryDesc: "Bo'zor bo'limlari bo'yicha katalog taqsimoti",
  productsLegend: 'Mahsulotlar',
  noProducts: "Hali mahsulotlar yo'q",
  ordersByStatus: "Holat bo'yicha buyurtmalar",
  ordersByStatusDesc: "Buyurtma hayotiy tsikli bosqichlari bo'yicha solishtirish",
  recentOrders: "So'nggi buyurtmalar",
  recentOrdersDesc: 'Eng yangi marketplace buyurtmalari',
  viewAllOrders: "Barchasini ko'rish"
} as const;

export const products = {
  title: 'Mahsulotlar',
  description: 'Xorijdan olib kelinadigan va yetkaziladigan mahsulotlarni boshqaring',
  add: "Mahsulot qo'shish",
  product: 'Mahsulot',
  category: "Bo'lim",
  price: 'Narx',
  discount: 'Chegirma',
  stock: 'Miqdor',
  status: 'Status',
  deleteTitle: "Mahsulotni o'chirish",
  deleteMessage: (name: string) => `<strong>${name}</strong> ni o'chirasizmi? Bu amalni ortga qaytarib bo'lmaydi.`,
  deleted: "Mahsulot o'chirildi",
  createSuccess: 'Mahsulot yaratildi',
  updateSuccess: 'Mahsulot yangilandi',
  addModal: "Mahsulot qo'shish",
  editModal: 'Mahsulotni tahrirlash',
  attributes: 'Xususiyatlar',
  attributesModal: 'Mahsulot xususiyatlari',
  attributesSaved: 'Xususiyatlar saqlandi'
} as const;

export const productSuggestions = {
  similarTitle: "O'xshash mahsulotlar",
  copy: 'Nusxalash',
  copyHint: "Bo'lim, tavsif, narx va rasmni ushbu mahsulotdan olish",
  copied: (name: string) => `"${name}" ma'lumotlari ko'chirildi`,
  duplicateTitle: 'Bunday mahsulot allaqachon mavjud',
  duplicateMessage: (name: string, category: string) =>
    `"${name}"${category ? ` (${category})` : ''} katalogda bor. Ikki marta qo'shmaganingizga ishonch hosil qiling.`,
  recommendedCategory: "Tavsiya etilgan bo'lim:",
  recommendedCategoryCount: (count: number, total: number) => `${total} ta o'xshash mahsulotdan ${count} tasi`,
  priceRangeSimilar: "O'xshash mahsulotlar narxi:",
  priceRangeCategory: "Bo'limdagi narxlar:",
  median: "o'rtacha",
  useMedian: "O'rtachani qo'yish"
} as const;

export const productEditor = {
  breadcrumbNew: 'Yangi mahsulot',
  breadcrumbEdit: 'Tahrirlash',
  titleCreate: "Mahsulot qo'shish",
  titleEdit: 'Mahsulotni tahrirlash',
  cancel: 'Bekor qilish',
  notFound: 'Mahsulot topilmadi',
  retry: 'Qayta urinish',
  optional: '(ixtiyoriy, lekin tavsiya etiladi)',

  // 01
  basic: "Asosiy ma'lumot",
  name: 'Mahsulot nomi',
  namePlaceholder: "Masalan: Ayollar yozgi ko'ylagi, gulli",
  description: 'Tavsif',
  descriptionPlaceholder: "Mahsulot haqida qisqacha ma'lumot: material, kesim, parvarish bo'yicha maslahat...",
  category: 'Kategoriya',
  categoryHint: "(nomi bo'yicha qidiring yoki pastdan bosqichma-bosqich tanlang)",
  categorySearchPlaceholder: "Masalan: ko'ylak, smartfon, shampun, gilam...",
  categoryNothingFound: 'Kategoriya topilmadi',
  level1: "Bo'lim",
  level2: 'Kategoriya',
  level3: 'Subkategoriya',
  choose: '— tanlang —',
  chooseDeeper: "Aniqroq kategoriyani tanlang — xususiyatlar shunga qarab o'zgaradi",
  variantChip: (names: string) => `Variant: ${names}`,
  translations: 'Tarjimalar (UZ / RU)',
  translationsHint: "UZ maydonlari bo'sh qolsa, asosiy nom va tavsif ishlatiladi",

  // 02
  specs: 'Kategoriyaga xos xususiyatlar',
  specsChooseCategory: 'Avval kategoriyani tanlang — xususiyatlar shunga qarab serverdan yuklanadi.',
  specsLoading: 'Xususiyatlar yuklanmoqda…',
  specsEmpty: "Bu kategoriya uchun qo'shimcha xususiyatlar yo'q.",
  specsError: "Xususiyatlarni yuklab bo'lmadi",
  specsBanner:
    "Maydonlar serverdagi atributlar ro'yxatidan keladi. Kategoriya o'zgarsa, avvalgi javoblar tozalanadi. Narx, ombor va variantlar — 3-bo'limda.",
  textPlaceholder: (name: string) => `Masalan: ${name}`,
  yes: 'Ha',
  no: "Yo'q",

  // 03
  pricing: 'Narxlar, foyda va variantlar',
  commission: (percent: number, tier: string) => `ZARO komissiyasi: ${percent}%${tier ? ` · ${tier}` : ''}`,
  variantInfoTitle: (names: string) => `Variant: ${names}.`,
  variantInfo: 'Har bir kombinatsiya alohida SKU va ombor hosil qiladi; narxlarni pastda belgilaysiz.',
  chooseMany: '(bir nechtasini tanlang)',
  purchasePrice: 'Xarid narxi',
  purchasePriceHint: '(sizga qancha turadi)',
  purchasePriceNote: "Sof foydani hisoblash uchun ishlatiladi — buni hech kim (mijoz) ko'rmaydi",
  onlinePrice: 'Onlayn sotuv narxi',
  discount: 'Chegirma',
  discountPrice: 'Chegirma narxi',
  storePrice: "Do'kon narxi",
  storePriceHint: '(komissiyasiz)',
  defaultStock: 'Standart ombor',
  stock: 'Ombor',
  currency: "so'm",
  pieces: 'dona',
  commissionRow: (percent: number) => `Komissiya (${percent}%)`,
  payout: 'Sizga tushadi',
  onlineProfit: 'Sof foyda (xarid narxidan keyin)',
  storeProfit: 'Sof foyda',
  generate: 'Variantlarni generatsiya qilish',
  regenerate: 'Variantlarni yangilash',
  variantsCount: (count: number) => `${count} ta variant`,
  variant: 'Variant',
  sku: 'SKU',
  variantPrice: 'Narx',
  variantStock: 'Ombor',
  removeVariant: "Variantni o'chirish",
  applyToAll: "Hammasiga qo'llash",

  // 04
  images: 'Rasmlar',
  addImage: "Qo'shish",
  mainImage: 'Asosiy',
  makeMain: 'Asosiy qilish',
  removeImage: "O'chirish",
  uploading: 'Yuklanmoqda…',
  imagesHint: "Birinchi rasm asosiy bo'ladi. PNG, JPG, WEBP.",
  imageTypeError: 'Faqat PNG, JPG, JPEG va WEBP rasmlar yuklash mumkin',

  // 05
  channels: 'Sotuv kanali',
  online: 'Onlayn',
  onlineHint: "ZARO ilovasida ko'rinadi",
  store: "Do'konda",
  storeHint: 'Faqat "Do\'kondan sotish"da',
  channelsNote: 'Ombor miqdori ikkala kanal uchun umumiy — yuqoridagi variant jadvalidagi sonlar ishlatiladi.',
  onlineAlert:
    "Mahsulot onlaynda ko'rinadi — admin tasdiqlashidan keyin faollashadi. Do'konda sotish esa tasdiqni kutmaydi.",

  // footer
  saveDraft: 'Qoralama sifatida saqlash',
  submitReview: "Ko'rib chiqishga yuborish",
  draftSaved: 'Qoralama saqlandi',
  submitted: "Mahsulot ko'rib chiqishga yuborildi",
  updated: 'Mahsulot yangilandi',
  fixErrors: "Belgilangan maydonlarni to'ldiring"
} as const;

export const categories = {
  title: "Bo'limlar",
  description: "Xorijiy mahsulotlarni ko'rish uchun bo'limlarga ajrating",
  add: "Bo'lim qo'shish",
  category: "Bo'lim",
  sortOrder: 'Index',
  status: 'Status',
  created: 'Yaratilgan',
  deleteTitle: "Bo'limni o'chirish",
  deleteMessage: (name: string) =>
    `<strong>${name}</strong> ni o'chirasizmi? Bu bo'limdagi mahsulotlar o'z holida qoladi.`,
  deleted: "Bo'lim o'chirildi",
  createSuccess: "Bo'lim yaratildi",
  updateSuccess: "Bo'lim yangilandi",
  addModal: "Bo'lim qo'shish",
  editModal: "Bo'limni tahrirlash"
} as const;

export const orders = {
  title: 'Buyurtmalar',
  description: "Buyurtma holatini ko'ring va yangilang. Mijozlar buyurtmalarni foydalanuvchi ilovasi orqali beradi.",
  orderNumber: 'ID',
  customer: 'Mijoz',
  items: 'Mahsulotlar',
  total: 'Jami',
  status: 'Status',
  delivery: 'Yetkazib berish',
  date: 'Sana',
  createModal: 'Buyurtma yaratish',
  updateStatusModal: 'Buyurtma holatini yangilash',
  allStatuses: 'Barcha statuslar',
  orderSummary: (id: number, name: string) => `Buyurtma <strong>#${id}</strong> — ${name}`,
  totalAmount: (amount: string) => `Jami: ${amount}`,
  created: 'Buyurtma yaratildi',
  statusUpdated: 'Buyurtma holati yangilandi',
  deleteTitle: "Buyurtmani o'chirish",
  deleted: "Buyurtma o'chirildi",
  open: 'Ochish',
  back: 'Orqaga',
  single: (id: number) => `Buyurtma #${id}`,
  singleDescription: "Buyurtma tarkibi, mijoz va to'lov ma'lumotlari",
  notFound: 'Buyurtma topilmadi',
  orderInfo: "Buyurtma ma'lumotlari",
  customerId: 'Mijoz ID',
  comment: 'Izoh',
  image: 'Rasm',
  product: 'Mahsulot',
  quantity: 'Miqdor',
  price: 'Narx',
  itemTotal: 'Summa',
  paymentInfo: "To'lov ma'lumotlari",
  noPayment: "To'lov ma'lumotlari yo'q",
  merchantTransId: 'Tranzaksiya ID',
  paymentAmount: "To'lov summasi",
  paymentUrl: "To'lov havolasi",
  openPaymentUrl: "To'lov sahifasini ochish",
  receipt: 'Chek rasmi',
  noReceipt: 'Chek rasmi yuklanmagan',
  noItems: "Buyurtmada mahsulotlar yo'q"
} as const;

export const paymentStatus = {
  WAITING: 'Kutilmoqda',
  PREPARED: 'Tayyorlangan',
  PAID: "To'langan",
  CANCELLED: 'Bekor qilingan',
  FAILED: 'Muvaffaqiyatsiz'
} as const;

export const users = {
  title: 'Mijozlar',
  description: 'Xorijdan mahsulot buyurtma qiladigan bozor mijozlarini boshqaring',
  add: "Mijoz qo'shish",
  name: 'Ism',
  email: 'Email',
  phone: 'Telefon',
  location: 'Manzil',
  joined: "Qo'shilgan",
  updated: 'Mijoz yangilandi',
  created: 'Mijoz yaratildi',
  deleted: "Mijoz o'chirildi",
  deleteTitle: "Mijozni o'chirish",
  deleteMessage: (name: string) => `<strong>${name}</strong> ni o'chirasizmi? Bu amalni ortga qaytarib bo'lmaydi.`,
  editModal: 'Mijozni tahrirlash',
  addModal: "Mijoz qo'shish"
} as const;

export const userTesting = {
  title: 'Foydalanuvchi API testi',
  description:
    "Foydalanuvchi JWT bilan mijoz endpointlarini sinab ko'ring. Faqat oddiy foydalanuvchilar buyurtma berishi mumkin.",
  userToken: 'Foydalanuvchi tokeni',
  tokenHint:
    "Mijoz tokenini joylashtiring yoki Telegram ID orqali kiring. Bu sahifadagi so'rovlar admin sessiyasidan emas, shu token orqali yuboriladi.",
  bearerToken: 'Bearer token',
  saveToken: 'Tokenni saqlash',
  clearToken: 'Tozalash',
  tokenActive: 'Token faol',
  telegramLogin: 'Yoki Telegram ID orqali kirish',
  getToken: 'Token olish',
  saveTokenFirst: 'Avval foydalanuvchi tokenini saqlang',
  tokenSaved: 'Foydalanuvchi tokeni saqlandi',
  tokenCleared: 'Foydalanuvchi tokeni tozalandi',
  pasteTokenFirst: 'Avval foydalanuvchi tokenini joylashtiring',
  invalidTelegramId: "To'g'ri Telegram ID kiriting",
  loggedIn: 'Foydalanuvchi sifatida kirdingiz',
  loginFailed: 'Kirish muvaffaqiyatsiz',
  orderPlaced: 'Buyurtma berildi',
  onlyUsersCanOrder: 'Faqat foydalanuvchilar buyurtma bera oladi',
  paymentCreated: "To'lov yaratildi",
  paymentSent: "To'lov so'rovi yuborildi",
  paymentFailed: "To'lov muvaffaqiyatsiz",
  profileFailed: "Profilni yuklab bo'lmadi",
  telegramId: 'Telegram ID',
  phone: 'Telefon',
  payment: "To'lov",
  pay: "To'lash",
  createPayment: "To'lov yaratish",
  placeOrder: 'Buyurtma berish',
  deliveryAddress: 'Yetkazib berish manzili',
  comment: 'Izoh',
  quantity: 'Miqdor',
  addItem: "Mahsulot qo'shish",
  removeItem: 'Mahsulotni olib tashlash',
  emptyState: 'Profil, mahsulotlar, buyurtmalar va buyurtma berish uchun foydalanuvchi tokenini saqlang.'
} as const;

export const forms = {
  category: "Bo'lim",
  name: 'Nomi',
  nameUz: 'Nomi (UZ)',
  nameRu: 'Nomi (RU)',
  description: 'Tavsif',
  descriptionUz: 'Tavsif (UZ)',
  descriptionRu: 'Tavsif (RU)',
  price: 'Narx',
  discountPrice: 'Chegirma narxi',
  stock: 'Ombor',
  sortOrder: 'Tartib raqami',
  imageUrl: 'Rasm',
  imagePlaceholder: 'Rasm faylini tanlang (PNG, JPEG, JPG, WEBP)',
  id: 'ID',
  activeVisible: "Faol (do'konda ko'rinadi)",
  product: 'Mahsulot',
  status: 'Holat',
  fullName: "To'liq ism",
  email: 'Email',
  phone: 'Telefon',
  country: 'Mamlakat',
  city: 'Shahar',
  slug: 'Slug',
  currency: 'Valyuta',
  originCountry: 'Kelib chiqqan mamlakat',
  originCountryPlaceholder: 'masalan, Yaponiya, Italiya',
  orderNumber: 'Buyurtma raqami',
  totalAmount: 'Umumiy summa',
  shippingCountry: 'Yetkazish mamlakat',
  shippingCity: 'Yetkazish shahri',
  shippingAddress: 'Yetkazish manzili',
  notes: 'Eslatmalar'
} as const;

export const validation = {
  usernameRequired: 'Foydalanuvchi nomi talab qilinadi',
  passwordRequired: 'Parol talab qilinadi',
  fullNameRequired: "To'liq ism talab qilinadi",
  invalidEmail: "Noto'g'ri email",
  emailRequired: 'Email talab qilinadi',
  phoneRequired: 'Telefon talab qilinadi',
  countryRequired: 'Mamlakat talab qilinadi',
  cityRequired: 'Shahar talab qilinadi',
  nameRequired: 'Nom talab qilinadi',
  nameUzRequired: "O'zbekcha nom talab qilinadi",
  nameRuRequired: 'Ruscha nom talab qilinadi',
  slugRequired: 'Slug talab qilinadi',
  slugFormat: 'Kichik harflar, raqamlar va defis ishlating',
  descriptionRequired: 'Tavsif talab qilinadi',
  descriptionUzRequired: "O'zbekcha tavsif talab qilinadi",
  descriptionRuRequired: 'Ruscha tavsif talab qilinadi',
  pricePositive: "Narx musbat bo'lishi kerak",
  priceRequired: 'Narx talab qilinadi',
  discountPositive: "Chegirma narxi musbat bo'lishi kerak",
  discountRequired: 'Chegirma narxi talab qilinadi',
  validUrl: "To'g'ri URL bo'lishi kerak",
  imageUrlRequired: 'Rasm talab qilinadi',
  stockRequired: 'Ombor talab qilinadi',
  sortOrderRequired: 'Tartib raqami talab qilinadi',
  idRequired: 'ID talab qilinadi',
  idPositive: "ID musbat butun son bo'lishi kerak",
  categoryRequired: 'Kategoriya talab qilinadi',
  currencyRequired: 'Valyuta talab qilinadi',
  originCountryRequired: 'Kelib chiqqan mamlakat talab qilinadi',
  productRequired: 'Mahsulot talab qilinadi',
  quantityMin: "Miqdor kamida 1 bo'lishi kerak",
  quantityRequired: 'Miqdor talab qilinadi',
  addAtLeastOneItem: "Kamida bitta mahsulot qo'shing",
  deliveryAddressRequired: 'Yetkazib berish manzili talab qilinadi',
  statusRequired: 'Holat talab qilinadi',
  orderNumberRequired: 'Buyurtma raqami talab qilinadi',
  customerRequired: 'Mijoz talab qilinadi',
  customerNameRequired: 'Mijoz ismi talab qilinadi',
  totalRequired: 'Jami summa talab qilinadi',
  shippingCountryRequired: 'Yetkazish mamlakat talab qilinadi',
  shippingCityRequired: 'Yetkazish shahri talab qilinadi',
  shippingAddressRequired: 'Yetkazish manzili talab qilinadi',
  purchasePriceRequired: 'Xarid narxini kiriting',
  discountBelowPrice: "Chegirma narxi sotuv narxidan past bo'lishi kerak",
  skuRequired: 'SKU kiriting',
  channelRequired: 'Kamida bitta sotuv kanalini yoqing',
  attributeRequired: (name: string) => `${name} majburiy`,
  generateVariants: 'Variantlarni generatsiya qiling',
  chooseVariantOptions: (names: string) => `${names} bo'yicha kamida bitta qiymat tanlang`
} as const;

export const orderStatusOptions = [
  { value: 'PENDING', label: orderStatus.pending },
  { value: 'PAID', label: orderStatus.paid },
  { value: 'PROCESSING', label: orderStatus.processing },
  { value: 'SHIPPED', label: orderStatus.shipped },
  { value: 'DELIVERED', label: orderStatus.delivered },
  { value: 'CANCELLED', label: orderStatus.cancelled }
] as const;

export const orderStatusLabel = (status: string) => {
  const map: Record<string, string> = {
    pending: orderStatus.pending,
    paid: orderStatus.paid,
    processing: orderStatus.processing,
    shipped: orderStatus.shipped,
    delivered: orderStatus.delivered,
    cancelled: orderStatus.cancelled
  };
  return map[status] ?? status;
};
